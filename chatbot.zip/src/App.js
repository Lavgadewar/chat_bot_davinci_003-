import "./App.css";
import Basic from "./chatbotComponents/chatbot";
import React from "react";
function App() {
  return (
    <div className="App">
      <h1></h1>
      <Basic />
    </div>
  );
}

export default App;
